module.exports = {
    SECRET: 'adshgdsajk1912389tyrsajodsad19527adjkls',
};